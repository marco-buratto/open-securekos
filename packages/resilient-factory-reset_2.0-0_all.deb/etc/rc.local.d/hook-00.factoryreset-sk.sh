#!/bin/bash

if grep -iq sk-factory-reset /proc/cmdline; then
    if grep -iq reset-confirm /proc/cmdline; then
        sudo /sbin/sk.factoryReset.sh
    fi
fi

