#!/bin/bash

set -e

# Get persistence partition block device.
systemDevice=$(mount | grep persistence | grep upperdir | grep -o -P '(?<=/persistence/).*(?=4/rw)')

if [ ! -z "$systemDevice" ]; then
	cd /lib/live/mount/persistence/${systemDevice}4/

	# Get the original kernel version.
	kVer=$(ls /lib/live/mount/rootfs/filesystem.squashfs/boot/vmlinuz* | awk -F'vmlinuz-' '{print $2}')

	# Restore original kernel files.
	for F in vmlinuz-${kVer} initrd.img-${kVer}; do
		if [ ! -f /boot/$F ]; then
			cp -f /lib/live/mount/rootfs/filesystem.squashfs/boot/$F /boot
		fi
	done

	# Rewrite iso kernel partition with the original kernel.
	# Get second system partition's device file and UUID.
	secondSystemPartition=${systemDevice}2 # example: sdb2.
	secondSystemPartitionUUID=$(blkid -o value -s UUID /dev/$secondSystemPartition | sed -e 's#-##g')

	if [ ! -z "$secondSystemPartitionUUID" ]; then
		# Second system partition re-write with updated kernel, initrd.
		cd /boot
		if [ -f vmlinuz-${kVer} ] && [ -f initrd.img-${kVer} ]; then
			mkdir -p temp/live
			cp -a vmlinuz-${kVer} temp/live/vmlinuz
			cp -a initrd.img-${kVer} temp/live/initrd.img
		   
			cd temp
			if mount | grep -q /dev/${secondSystemPartition}; then
				umount /dev/${secondSystemPartition}
			fi

			xorrisofs -volid SK-SYSTEM2 --modification-date=$secondSystemPartitionUUID -o /dev/$secondSystemPartition . 
   
			cd ..
			rm -fR temp
	        fi
	fi
				 
	# Remove all persistence files.
	cd /lib/live/mount/persistence/${systemDevice}4/
	rm -Rf rw

	chvt 5; sync; /sbin/reboot -f
fi

exit 0
