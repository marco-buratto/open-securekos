#!/bin/bash

# Set GDM daemon settings about auto-login as our default and reset default wm, if no sk- boot kernel parameter is set.
if ! grep -iq sk- /proc/cmdline; then
    sed -i 's/^AutomaticLoginEnable =.*/#  AutomaticLoginEnable = true/g' /etc/gdm3/daemon.conf
    sed -i 's/^AutomaticLogin =.*/#  AutomaticLogin = sk-system/g' /etc/gdm3/daemon.conf

    update-alternatives --set x-session-manager /usr/bin/gnome-session
fi

# Reset the system to factory settings (if booted with the "sk-factory-reset" kernel parameter).
if [ -f /sbin/sk.factoryReset.sh ]; then
    if grep -iq sk-factory-reset /proc/cmdline; then
        # Set GDM so that it auto-logins the sk-system user.
        sed -i 's/^#  AutomaticLoginEnable =.*/AutomaticLoginEnable = true/g' /etc/gdm3/daemon.conf
        sed -i 's/^#  AutomaticLogin =.*/AutomaticLogin = sk-system/g' /etc/gdm3/daemon.conf

        # Setting mutter as the default wm.
        update-alternatives --set x-session-manager /usr/bin/mutter

        # sk-system user will launch the reset GUI onto mutter, thanks to his .profile.
    fi
fi

exit 0
