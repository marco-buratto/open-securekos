#!/bin/bash

if cat /proc/cmdline | grep -q kernel-partition-restore; then
	(dpkg --configure -a && apt install -f && halt -fpn) &
fi

exit 0
