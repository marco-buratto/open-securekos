#!/bin/bash

set -e

# Get persistence partition block device.
systemDevice=$(mount | grep persistence | grep upperdir | grep -o -P '(?<=/persistence/).*(?=4/rw)')

if [ ! -z "$systemDevice" ]; then
	cd /lib/live/mount/persistence/${systemDevice}4/

	# Check if the user really wants to proceed.
	zenity  --question --title "Reset to Factory Settings"  --text "This operation will reset Resilient Linux to it factory settings, therefore deleting all your data,\nsoftware and customizations. Do you really want to proceed?\n\nWARNING: all your data will be erased, this operation is irreversible!\nFilesystem encryption password won't be touched (if any)." 2> /dev/null

	if [ "$?" == 1 ]; then
		if grep -iq sk-factory-reset /proc/cmdline; then
		    reboot
		fi

		exit 1
	fi

	# Get the original kernel version.
	kVer=$(ls /lib/live/mount/rootfs/filesystem.squashfs/boot/vmlinuz* | awk -F'vmlinuz-' '{print $2}')

	# Restore original kernel files.
	for F in vmlinuz-${kVer} initrd.img-${kVer}; do
	    if [ ! -f /boot/$F ]; then
		cp -f /lib/live/mount/rootfs/filesystem.squashfs/boot/$F /boot
	    fi
	done

	# Rewrite iso kernel partition with the original kernel.
	# Get second system partition's device file and UUID.
	secondSystemPartition=${systemDevice}2 # example: sdb2.
	secondSystemPartitionUUID=$(blkid -o value -s UUID /dev/$secondSystemPartition | sed -e 's#-##g')

	if [ ! -z "$secondSystemPartitionUUID" ]; then
		# Second system partition re-write with updated kernel, initrd.
		cd /boot
		if [ -f vmlinuz-${kVer} ] && [ -f initrd.img-${kVer} ]; then
			mkdir -p temp/live
			cp -a vmlinuz-${kVer} temp/live/vmlinuz
			cp -a initrd.img-${kVer} temp/live/initrd.img
		   
			cd temp
			if mount | grep -q /dev/${secondSystemPartition}; then
				umount /dev/${secondSystemPartition}
			fi

			if ! xorrisofs -volid SECURE-K2 --modification-date=$secondSystemPartitionUUID -o /dev/$secondSystemPartition . ; then
                                zenity --warning --title "Reset to Factory Settings" --text "Fatal error: second system partition write failed!" 2>/dev/null
				exit 1
			fi
   
			cd ..
			rm -fR temp
	        fi
	fi
				 
	# Remove all persistence files.
	cd /lib/live/mount/persistence/${systemDevice}4/
	rm -Rf rw

	zenity --warning --title "Reset to Factory Settings" --text "System is reset to Factory Settings, click OK to shutdown the system." 2> /dev/null
	chvt 5; sync; /sbin/halt -p
fi

exit 0
